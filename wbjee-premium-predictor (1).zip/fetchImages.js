import fs from 'fs';

const colleges = [
  { id: 'JU', name: 'Jadavpur_University' },
  { id: 'CU', name: 'University_of_Calcutta' },
  { id: 'HIT', name: 'Heritage_Institute_of_Technology' },
  { id: 'NSEC', name: 'Netaji_Subhash_Engineering_College' },
  { id: 'RCCIIT', name: 'RCC_Institute_of_Information_Technology' },
  { id: 'AOT', name: 'Academy_of_Technology' },
  { id: 'CGEC', name: 'Cooch_Behar_Government_Engineering_College' },
  { id: 'GCELT', name: 'Government_College_of_Engineering_and_Leather_Technology' },
];

async function fetchImage(college) {
  const url = `https://en.wikipedia.org/w/api.php?action=query&titles=${encodeURIComponent(college.name)}&prop=pageimages&format=json&pithumbsize=1000`;
  try {
    const res = await fetch(url);
    const data = await res.json();
    const pages = data.query.pages;
    const pageId = Object.keys(pages)[0];
    if (pageId !== '-1' && pages[pageId].thumbnail) {
      console.log(`${college.id}|${pages[pageId].thumbnail.source}`);
    } else {
      console.log(`${college.id}|Not found`);
    }
  } catch (e) {
    console.log(`${college.id}|Error`);
  }
}

async function run() {
  for (const c of colleges) {
    await fetchImage(c);
  }
}
run();
