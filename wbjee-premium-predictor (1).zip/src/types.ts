export type Category = 'OPEN' | 'OBC-A' | 'OBC-B' | 'SC' | 'ST' | 'TFW';
export type Round = 1 | 2 | 3; // Typically Round 1, 2, and Mop-up (3)

export interface CollegeInfo {
  id: string;
  name: string;
  type: 'Govt' | 'Private' | 'University';
  location: string;
  description?: string;
  established?: number;
  highestPackage?: string;
  averagePackage?: string;
  imageUrl?: string;
  fees?: string;
  nirfRank?: number | string;
  reviews?: { user: string; text: string; rating: number }[];
  pros?: string[];
  cons?: string[];
}

export interface HistoricalCutoff {
  year: number;
  openingRank: number;
  closingRank: number;
}

export interface CutoffRecord {
  id: string;
  collegeId: string;
  branch: string;
  category: Category;
  round: Round;
  historicalCutoffs?: HistoricalCutoff[];
  openingRank: number;
  closingRank: number;
  expectedOpeningRank: number;
  expectedClosingRank: number;
  trend: 'Tougher' | 'Easier' | 'Stable';
}

export interface PredictionResult extends CutoffRecord {
  college: CollegeInfo;
  chance: 'High' | 'Medium' | 'Low';
}

export interface PredictorState {
  name: string;
  marks: number | '';
  targetCollege: string;
  rank: number | '';
  category: Category;
  round: Round;
  domicile: boolean; // WB domicile needed for categories & govt colleges mostly
}

