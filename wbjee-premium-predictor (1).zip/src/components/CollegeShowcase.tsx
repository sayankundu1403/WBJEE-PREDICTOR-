import React from 'react';
import { COLLEGES } from '../data/wbjeeData';
import { motion } from 'motion/react';
import { MapPin, ShieldCheck, Target, Building2, Briefcase, Calendar, Award, Banknote } from 'lucide-react';
import { cn } from '../lib/utils';

export function CollegeShowcase() {
  const collegesList = Object.values(COLLEGES);

  return (
    <div id="colleges-section" className="w-full max-w-7xl mx-auto py-24 px-4 border-t border-white/5 mt-10">
      <div className="text-center max-w-2xl mx-auto mb-16">
        <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-4 tracking-tight">Explore Participating Institutes</h2>
        <p className="text-slate-400 leading-relaxed font-medium">
          We track placement records, past cutoffs, and infrastructure data across the top government and private engineering colleges in West Bengal.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {collegesList.map((college, idx) => (
          <motion.div
            key={college.id}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-50px" }}
            transition={{ delay: Math.min(idx * 0.05, 0.4) }}
            className="group relative bg-[#151a22] border border-white/5 shadow-sm rounded-2xl overflow-hidden hover:border-white/20 transition-all duration-300 flex flex-col"
          >
            {/* Image Header */}
            {college.imageUrl && (
              <div className="w-full h-40 overflow-hidden relative">
                <div className="absolute inset-0 bg-gradient-to-t from-[#151a22] via-[#151a22]/60 to-transparent z-10" />
                <img 
                  src={college.imageUrl} 
                  alt={college.name} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
                
                {college.nirfRank && (
                   <div className="absolute top-3 right-3 z-20 bg-brand-500 text-white font-bold px-2.5 py-1 rounded-md text-xs flex items-center gap-1 shadow-sm">
                     <Award className="w-3 h-3" /> NIRF {college.nirfRank}
                   </div>
                )}
              </div>
            )}

            <div className="p-6 flex-grow flex flex-col">
              <div className="flex items-start justify-between mb-4 -mt-2 relative z-20">
                <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider bg-[#0b0e14] backdrop-blur-md text-slate-300 border border-white/10 shadow-sm">
                  {college.type === 'Govt' ? (
                    <><ShieldCheck className="w-3 h-3 text-brand-400" /> Govt. Inst.</>
                  ) : college.type === 'University' ? (
                    <><Target className="w-3 h-3 text-blue-400" /> State Univ.</>
                  ) : (
                    <><Building2 className="w-3 h-3 text-slate-400" /> Private</>
                  )}
                </span>
                {college.id === 'JU' && (
                  <span className="inline-flex h-2 w-2 rounded-full bg-brand-500 ring-4 ring-brand-500/20" />
                )}
              </div>

              <h3 className="text-xl font-display font-bold text-white leading-tight mb-2">
                {college.name}
              </h3>
              
              <div className="flex items-center gap-1.5 text-slate-400 text-sm mb-4 font-medium">
                <MapPin className="w-4 h-4 text-slate-500" />
                {college.location}
              </div>

              <p className="text-sm text-slate-400 leading-relaxed mb-6 line-clamp-3">
                {college.description || 'A highly esteemed institution offering quality engineering programs.'}
              </p>

              <div className="space-y-3 pt-4 border-t border-white/5 mt-auto">
                {college.fees && (
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-500 flex items-center gap-1.5 font-medium"><Banknote className="w-4 h-4 text-slate-600" /> Approx. Fees</span>
                    <span className="text-slate-200 font-semibold">{college.fees}</span>
                  </div>
                )}
                {college.established && (
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-500 flex items-center gap-1.5 font-medium"><Calendar className="w-4 h-4 text-slate-600" /> Established</span>
                    <span className="text-slate-200 font-semibold">{college.established}</span>
                  </div>
                )}
                {college.highestPackage && (
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-500 flex items-center gap-1.5 font-medium"><Briefcase className="w-4 h-4 text-emerald-500" /> Highest CTC</span>
                    <span className="text-slate-200 font-semibold">{college.highestPackage}</span>
                  </div>
                )}
                {college.averagePackage && (
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-500 flex items-center gap-1.5 font-medium"><Briefcase className="w-4 h-4 text-brand-400" /> Average CTC</span>
                    <span className="text-slate-200 font-semibold">{college.averagePackage}</span>
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
