import React, { useState } from 'react';
import { Input } from './ui/Input';
import { Select } from './ui/Select';
import { Category, Round, PredictorState } from '../types';
import { Sparkles, ShieldQuestion, Activity } from 'lucide-react';
import { motion } from 'motion/react';
import { COLLEGES } from '../data/wbjeeData';

interface PredictorFormProps {
  onPredict: (state: PredictorState) => void;
  isLoading?: boolean;
}

const CATEGORY_OPTIONS = [
  { label: 'General / OPEN', value: 'OPEN' },
  { label: 'OBC - A', value: 'OBC-A' },
  { label: 'OBC - B', value: 'OBC-B' },
  { label: 'SC', value: 'SC' },
  { label: 'ST', value: 'ST' },
  { label: 'Tuition Fee Waiver (TFW)', value: 'TFW' }
];

const ROUND_OPTIONS = [
  { label: 'Round 1 (Most Accurate)', value: 1 },
  { label: 'Round 2', value: 2 },
  { label: 'Mop-up Round (Round 3)', value: 3 },
];

const COLLEGE_OPTIONS = [
  { label: 'Any / Open to all', value: 'Any' },
  ...Object.values(COLLEGES).map(c => ({ label: c.name, value: c.id }))
];

export function PredictorForm({ onPredict, isLoading }: PredictorFormProps) {
  const [state, setState] = useState<PredictorState>({
    name: '',
    marks: '',
    targetCollege: 'Any',
    rank: '',
    category: 'OPEN',
    round: 1,
    domicile: true
  });

  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!state.name.trim()) {
      setError('Please enter your name');
      return;
    }
    if (!state.rank || state.rank <= 0) {
      setError('Please enter a valid rank required for prediction');
      return;
    }
    setError('');
    onPredict(state);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="p-[1px] rounded-2xl bg-gradient-to-br from-slate-800 via-slate-800/50 to-slate-900 w-full max-w-3xl mx-auto shadow-2xl relative overflow-hidden"
    >
      {/* Glow effect */}
      <div className="absolute -top-32 -right-32 w-64 h-64 bg-brand-500/20 blur-3xl rounded-full pointer-events-none" />
      <div className="absolute -bottom-32 -left-32 w-64 h-64 bg-blue-500/20 blur-3xl rounded-full pointer-events-none" />

      <form onSubmit={handleSubmit} className="relative bg-[#0F1219]/90 backdrop-blur-xl p-6 sm:p-8 rounded-[14px] flex flex-col gap-6">
        
        <div className="flex flex-col items-center text-center space-y-2 mb-2">
          <div className="bg-[#1A1F2B] border border-white/5 w-12 h-12 flex items-center justify-center rounded-2xl mb-2 text-brand-500 shadow-sm">
            <Activity className="w-6 h-6" />
          </div>
          <h2 className="text-2xl font-display font-bold tracking-tight text-white">Enter Your Details</h2>
          <p className="text-slate-400 text-sm font-medium">We use thousands of data points to find your exact college match.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 bg-[#151a22]/50 p-6 rounded-2xl border border-white/5">
          <div className="md:col-span-2">
            <Input 
              label="Full Name"
              type="text"
              placeholder="e.g. Rahul Kumar"
              value={state.name}
              onChange={(e) => setState(prev => ({ ...prev, name: e.target.value }))}
              error={error && !state.name ? error : undefined}
              autoFocus
            />
          </div>

          <Input 
            label="WBJEE GMR Rank"
            type="number"
            min="1"
            max="150000"
            placeholder="e.g. 4500"
            value={state.rank}
            onChange={(e) => setState(prev => ({ ...prev, rank: e.target.value ? parseInt(e.target.value) : '' }))}
            error={error && !state.rank ? error : undefined}
          />
          
          <Input 
            label="WBJEE Marks (Optional)"
            type="number"
            min="0"
            max="200"
            placeholder="e.g. 85"
            value={state.marks}
            onChange={(e) => setState(prev => ({ ...prev, marks: e.target.value ? parseInt(e.target.value) : '' }))}
          />

          <div className="md:col-span-2">
            <Select 
              label="Target College (Optional)"
              options={COLLEGE_OPTIONS}
              value={state.targetCollege}
              onChange={(e) => setState(prev => ({ ...prev, targetCollege: e.target.value }))}
            />
          </div>

          <Select 
            label="Reservation Category"
            options={CATEGORY_OPTIONS}
            value={state.category}
            onChange={(e) => setState(prev => ({ ...prev, category: e.target.value as Category }))}
          />
          <Select 
            label="Counselling Round"
            options={ROUND_OPTIONS}
            value={state.round}
            onChange={(e) => setState(prev => ({ ...prev, round: parseInt(e.target.value) as Round }))}
          />
        </div>

        <button 
          type="submit"
          disabled={isLoading}
          className="mt-2 w-full rounded-xl bg-brand-500 hover:bg-brand-400 text-white font-bold py-3.5 px-8 transition-colors flex items-center justify-center gap-2 shadow-lg"
        >
          {isLoading ? (
            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
          ) : (
            <>
              Predict My Colleges
              <Sparkles className="w-4 h-4 ml-1" />
            </>
          )}
        </button>

      </form>
    </motion.div>
  );
}
