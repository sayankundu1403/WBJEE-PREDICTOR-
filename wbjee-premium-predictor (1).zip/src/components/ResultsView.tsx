import React, { useState, useMemo } from 'react';
import { PredictionResult, PredictorState } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { MapPin, ArrowRight, ShieldCheck, Target, AlertTriangle, Building2, Briefcase, Calendar, ChevronDown, ChevronUp, Download, SlidersHorizontal, Award, Banknote, TrendingDown, TrendingUp, Minus, FileText, Star, CheckCircle2, XCircle } from 'lucide-react';
import { cn } from '../lib/utils';
import { COLLEGES } from '../data/wbjeeData';

interface ResultsViewProps {
  results: PredictionResult[];
  state: PredictorState;
}

type SortOption = 'chance' | 'closingRankAsc' | 'closingRankDesc' | 'name';

interface GroupedResult {
  collegeId: string;
  college: PredictionResult['college'];
  branches: PredictionResult[];
  bestChanceWeight: number;
  minClosingRank: number;
}

export function ResultsView({ results, state }: ResultsViewProps) {
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState<SortOption>('chance');
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);

  const rank = state.rank as number;

  const groupedResults = useMemo(() => {
    const chanceWeight = { 'High': 3, 'Medium': 2, 'Low': 1 };
    const groups: Record<string, GroupedResult> = {};

    results.forEach(item => {
      const cid = item.collegeId;
      if (!groups[cid]) {
        groups[cid] = {
          collegeId: cid,
          college: item.college,
          branches: [],
          bestChanceWeight: 0,
          minClosingRank: 999999
        };
      }
      groups[cid].branches.push(item);
      const cw = chanceWeight[item.chance] || 1;
      if (cw > groups[cid].bestChanceWeight) {
        groups[cid].bestChanceWeight = cw;
      }
      if (item.expectedClosingRank < groups[cid].minClosingRank) {
        groups[cid].minClosingRank = item.expectedClosingRank;
      }
    });

    const arr = Object.values(groups);

    switch (sortBy) {
      case 'chance':
        arr.sort((a, b) => {
          if (b.bestChanceWeight !== a.bestChanceWeight) {
            return b.bestChanceWeight - a.bestChanceWeight;
          }
          return a.minClosingRank - b.minClosingRank;
        });
        break;
      case 'closingRankAsc':
        arr.sort((a, b) => a.minClosingRank - b.minClosingRank);
        break;
      case 'closingRankDesc':
        arr.sort((a, b) => b.minClosingRank - a.minClosingRank);
        break;
      case 'name':
        arr.sort((a, b) => a.college.name.localeCompare(b.college.name));
        break;
    }
    
    // Sort branches within each group
    arr.forEach(group => {
       group.branches.sort((a, b) => {
         if (chanceWeight[b.chance] !== chanceWeight[a.chance]) {
            return (chanceWeight[b.chance] || 1) - (chanceWeight[a.chance] || 1);
         }
         return a.expectedClosingRank - b.expectedClosingRank;
       });
    });

    return arr;
  }, [results, sortBy]);

  const handlePrint = async () => {
    setIsGeneratingPdf(true);
    try {
      // Import html2pdf dynamically to avoid SSR/build issues in some environments
      // Wait for Framer Motion to expand all the stream details
      await new Promise(resolve => setTimeout(resolve, 800));

      const element = document.getElementById('pdf-report-content');
      if (!element) return;
      
      const html2pdf = (await import('html2pdf.js')).default;
      
      const opt = {
        margin:       10,
        filename:     `WBJEE_Predictor_${state.name}_Rank${rank}.pdf`,
        image:        { type: 'jpeg', quality: 0.98 },
        html2canvas:  { scale: 2, windowWidth: 1024, useCORS: true },
        jsPDF:        { unit: 'mm', format: 'a4', orientation: 'portrait' }
      };

      await html2pdf().from(element).set(opt).save();
    } catch (e) {
      console.error('PDF generation failed', e);
      // Fallback
      window.print();
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  if (results.length === 0) {
    return (
      <motion.div 
        initial={{ opacity: 0 }} 
        animate={{ opacity: 1 }} 
        className="w-full max-w-4xl mx-auto py-16 text-center print:hidden"
      >
        <div className="bg-[#151a22] border border-red-500/20 p-10 rounded-3xl mb-8 flex flex-col items-center max-w-2xl mx-auto shadow-[0_0_50px_rgba(239,68,68,0.05)]">
          <AlertTriangle className="w-16 h-16 text-red-500 mb-6" />
          <h2 className="text-3xl font-display font-bold text-white mb-4">
            {state.targetCollege !== 'Any' ? `No Streams Found in ${COLLEGES[state.targetCollege]?.name || 'Target Institute'}` : "No Safe Matches Found"}
          </h2>
          <p className="text-slate-400 text-lg leading-relaxed mb-6">
            Based on a rank of <strong className="text-white bg-white/5 px-2 py-1 rounded">{rank}</strong>, we couldn't find a realistic match{state.targetCollege !== 'Any' ? ' in this specific institute' : ''} using our 15% buffer modeling. 
          </p>
          <div className="bg-red-500/10 text-red-400 px-6 py-4 rounded-xl border border-red-500/20 text-sm flex gap-3 text-left">
            <span className="w-2 rounded bg-red-500 shrink-0" />
            Consider exploring other institutions, or analyzing different counseling rounds where cutoffs may drop further.
          </div>
        </div>
      </motion.div>
    );
  }

  const highChances = results.filter(r => r.chance === 'High').length;

  return (
    <div className="w-full max-w-5xl mx-auto py-8 px-4 relative">
      
      <AnimatePresence>
        {isGeneratingPdf && (
           <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-24 left-1/2 -translate-x-1/2 z-[100] bg-brand-500 text-white px-6 py-3 rounded-full shadow-2xl font-bold flex items-center gap-2 print:hidden"
          >
             <Download className="w-5 h-5 animate-bounce" /> Generating Comprehensive PDF...
          </motion.div>
        )}
      </AnimatePresence>

      <div id="pdf-report-content" className="print:bg-white print:text-slate-900 pb-12">
        <div className="hidden print:block mb-8 mt-4 px-4 border-b-2 border-brand-500 pb-4">
          <div className="flex items-center gap-4 mb-4">
            <div className="bg-brand-500 p-2 rounded-lg text-white">
               <MapPin className="w-6 h-6" />
            </div>
            <h1 className="text-3xl font-display font-bold text-slate-900">Comprehensive Counseling Report</h1>
          </div>
          <p className="text-slate-600 mb-2">Analysis generated for <strong>{state.name}</strong></p>
          <div className="grid grid-cols-2 text-sm text-slate-700 max-w-md bg-slate-50 p-4 border border-slate-200 rounded-lg">
            <div><span className="font-bold">Predicted Rank:</span> {rank}</div>
            {state.marks !== '' && <div><span className="font-bold">WBJEE Marks:</span> {state.marks}</div>}
            <div><span className="font-bold">Category:</span> {state.category}</div>
            <div><span className="font-bold">Domicile:</span> {state.domicile ? 'West Bengal' : 'Other State'}</div>
            <div className="col-span-2"><span className="font-bold">Target Institute:</span> {state.targetCollege === 'Any' ? 'Open to All' : COLLEGES[state.targetCollege]?.name || 'Any'}</div>
          </div>
        </div>

        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: "easeOut" }}
          className="mb-10 p-6 bg-[#151a22] border border-white/10 rounded-2xl shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-6 print:hidden"
        >
          <div>
            <h2 className="text-2xl font-display font-bold text-white tracking-tight mb-1">Analysis Complete for {state.name}</h2>
            <p className="text-slate-400 text-sm mb-4">Rank {rank} • {state.category} • {state.marks !== '' ? `${state.marks} Marks` : 'Marks not provided'}</p>
            <div className="flex flex-wrap gap-4 mt-2 text-sm text-slate-300">
              <div className="flex items-center gap-2 bg-[#0b0e14] px-4 py-2 rounded-lg border border-white/5 font-medium">
                <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span className="font-bold text-white">{highChances}</span> High Probability Subjects
              </div>
              <div className="flex items-center gap-2 bg-[#0b0e14] px-4 py-2 rounded-lg border border-white/5 font-medium">
                <Building2 className="w-4 h-4 text-brand-400" />
                <span className="font-bold text-white">{groupedResults.filter(g => g.college.type === 'Govt' || g.college.type === 'University').length}</span> Gov/University Options
              </div>
            </div>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-3 mt-4 md:mt-0">
            <div className="relative">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as SortOption)}
                className="appearance-none bg-[#0b0e14] border border-white/10 text-slate-200 text-sm rounded-xl px-4 py-2.5 pr-10 shadow-sm focus:outline-none focus:ring-2 focus:ring-brand-500 h-full w-full sm:w-auto font-semibold"
              >
                <option value="chance">Sort by Probability</option>
                <option value="closingRankAsc">Toughest to Get In</option>
                <option value="closingRankDesc">Easiest to Get In</option>
                <option value="name">College Name (A-Z)</option>
              </select>
              <SlidersHorizontal className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 pointer-events-none" />
            </div>
            
            <button 
              onClick={handlePrint}
              disabled={isGeneratingPdf}
              className="flex items-center justify-center gap-2 bg-brand-500 hover:bg-brand-400 disabled:bg-brand-500/50 text-white font-semibold px-5 py-2.5 rounded-xl transition-colors shadow-sm h-full"
            >
              <Download className="w-4 h-4" /> {isGeneratingPdf ? 'Generating...' : 'Save PDF Report'}
            </button>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 gap-8 print:block print:space-y-8 print:px-4">
          <AnimatePresence>
            {groupedResults.map((group, idx) => {
              const isExpanded = expandedId === group.collegeId;
              const overallChance = group.bestChanceWeight === 3 ? 'High' : group.bestChanceWeight === 2 ? 'Medium' : 'Low';
              
              return (
                <motion.div
                  key={group.collegeId}
                  layout="position"
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: Math.min(idx * 0.05, 0.3) }}
                  className={cn(
                    "rounded-2xl transition-all duration-300 print:break-inside-avoid print:bg-white print:border print:border-slate-300 print:shadow-none overflow-hidden",
                    "border border-white/10 bg-[#151a22] hover:border-brand-500/50 hover:shadow-[0_0_30px_rgba(249,115,22,0.1)]",
                    isExpanded ? "border-brand-500/50 shadow-lg" : ""
                  )}
                >
                  <div 
                    className="p-5 cursor-pointer print:p-6 print:pb-4 flex flex-col md:flex-row gap-6 items-start md:items-center"
                    onClick={() => setExpandedId(isExpanded ? null : group.collegeId)}
                  >
                    <div className="relative w-full md:w-40 h-32 rounded-xl overflow-hidden shrink-0 border border-white/10 print:border-slate-200">
                      <div className="absolute inset-0 bg-gradient-to-t from-[#151a22] via-[#151a22]/40 to-transparent z-10 print:hidden" />
                      <img 
                        src={group.college.imageUrl} 
                        alt={group.college.name} 
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover transition-transform duration-700 hover:scale-110"
                      />
                      <div className="absolute bottom-3 left-3 z-20 flex gap-1 print:hidden">
                        <span className={cn(
                          "px-2 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider backdrop-blur-md border",
                          overallChance === 'High' ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/30" :
                          overallChance === 'Medium' ? "bg-amber-500/20 text-amber-300 border-amber-500/30" :
                          "bg-red-500/20 text-red-300 border-red-500/30"
                        )}>
                          {overallChance} Probability
                        </span>
                      </div>
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap gap-2 mb-2">
                        <span className={cn(
                          "px-2.5 py-1 rounded-md text-xs font-bold uppercase border print:border print:bg-slate-50",
                          group.college.type === 'Govt' || group.college.type === 'University' ? "bg-brand-500/10 text-brand-400 print:text-brand-700 print:border-brand-200 border-brand-500/20" : "bg-white/5 text-slate-300 border-white/10 print:text-slate-600 print:border-slate-200"
                        )}>
                          {group.college.type === 'University' ? "State University" : 
                           group.college.type === 'Govt' ? "Govt. College" : 
                           "Private Institute"}
                        </span>
                        {group.college.nirfRank && (
                           <span className="px-2.5 py-1 rounded-md text-xs font-bold uppercase bg-blue-500/10 text-blue-400 border border-blue-500/20 print:bg-blue-50 print:text-blue-700 print:border-blue-200">
                             NIRF {group.college.nirfRank}
                           </span>
                        )}
                      </div>
                      <h3 className="text-3xl font-display font-bold text-white leading-tight print:text-slate-900 mb-2">
                        {group.college.name}
                      </h3>
                      <div className="flex items-center gap-1.5 text-slate-400 text-sm font-medium print:text-slate-600 mb-3">
                        <MapPin className="w-4 h-4 text-slate-500 print:text-slate-500" />
                        {group.college.location}
                        <span className="mx-2 opacity-50">•</span>
                        <span className="text-brand-400 print:text-brand-600 font-bold">{group.branches.length} Match{group.branches.length > 1 ? 'es' : ''} Found</span>
                      </div>
                    </div>
                    
                    <div className="shrink-0 flex items-center justify-between w-full md:w-auto md:ml-auto md:pl-4 border-t border-white/5 md:border-t-0 md:border-l print:hidden pt-4 md:pt-0">
                       <button 
                          onClick={(e) => {
                             e.stopPropagation();
                             setExpandedId(isExpanded ? null : group.collegeId);
                          }}
                          className="flex items-center gap-2 text-sm font-bold text-brand-400 hover:text-brand-300 transition-colors bg-brand-500/10 px-4 py-2 rounded-xl border border-brand-500/20"
                        >
                         {isExpanded ? 'Hide Options' : 'View Streams'}
                         {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                       </button>
                    </div>
                  </div>

                  <AnimatePresence initial={false}>
                    {(isExpanded || isGeneratingPdf) && (
                      <motion.div
                        key={`expand-${group.collegeId}`}
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.4, ease: [0.04, 0.62, 0.23, 0.98] }}
                        className="overflow-hidden print:!h-auto print:!opacity-100 print:block flex flex-col"
                      >
                        <div className="p-5 pt-0 print:p-6 print:pt-0">
                          
                          <motion.div 
                            className="space-y-4 pt-4 border-t border-white/5 print:border-slate-200"
                            initial="hidden"
                            animate="visible"
                            variants={{
                              hidden: { opacity: 0 },
                              visible: {
                                opacity: 1,
                                transition: { staggerChildren: 0.1 }
                              }
                            }}
                          >
                            {group.branches.map((item, bIdx) => (
                              <motion.div 
                                key={bIdx} 
                                variants={{
                                  hidden: { opacity: 0, y: 10 },
                                  visible: { opacity: 1, y: 0 }
                                }}
                                className="bg-[#0b0e14] rounded-xl border border-white/5 overflow-hidden print:bg-white print:border-slate-300 print:shadow-sm"
                              >
                                <div className="p-4 md:px-5 flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-white/5 print:border-slate-200 print:bg-slate-50">
                                   <div className="text-lg md:text-xl font-bold text-white print:text-slate-800 flex items-center gap-2">
                                     <div className="w-2 h-2 rounded-full bg-brand-500 shrink-0 print:bg-brand-600" /> {item.branch}
                                   </div>
                                   <div className="flex items-center gap-3">
                                      <span className={cn(
                                        "px-3 py-1 rounded-md text-xs font-bold uppercase tracking-wider backdrop-blur-md border inline-block",
                                        item.chance === 'High' ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20 print:bg-emerald-50 print:text-emerald-700 print:border-emerald-200" :
                                        item.chance === 'Medium' ? "bg-amber-500/10 text-amber-400 border-amber-500/20 print:bg-amber-50 print:text-amber-700 print:border-amber-200" :
                                        "bg-red-500/10 text-red-400 border-red-500/20 print:bg-red-50 print:text-red-700 print:border-red-200"
                                      )}>
                                        {item.chance} Chance
                                      </span>
                                   </div>
                                </div>
                                
                                <div className="grid grid-cols-3 text-[10px] sm:text-xs uppercase tracking-wider font-bold text-slate-500 bg-[#1A1F2B] border-b border-white/5 p-2 sm:p-3 sm:px-5 print:bg-slate-100 print:text-slate-700 print:border-slate-200">
                                  <div>Round & Year</div>
                                  <div>OR (Opening Rank)</div>
                                  <div>CR (Closing Rank)</div>
                                </div>
          
                                {item.historicalCutoffs?.map((hist) => (
                                  <div key={hist.year} className="grid grid-cols-3 gap-2 sm:gap-4 p-2 sm:p-3 sm:px-5 border-b border-white/5 items-center print:border-slate-200 opacity-70 hover:opacity-100 transition-opacity print:opacity-100">
                                    <div className="text-xs sm:text-sm font-semibold text-slate-400 print:text-slate-600">Round {item.round} ({hist.year})</div>
                                    <div className="text-xs sm:text-sm font-mono text-slate-400 print:text-slate-500">{hist.openingRank.toLocaleString()}</div>
                                    <div className="text-xs sm:text-sm font-mono text-slate-400 print:text-slate-500">{hist.closingRank.toLocaleString()}</div>
                                  </div>
                                ))}
          
                                <div className="grid grid-cols-3 gap-2 sm:gap-4 p-2 sm:p-3 sm:px-5 border-b border-white/5 items-center print:border-slate-200 bg-white/[0.02] print:bg-transparent">
                                  <div className="text-xs sm:text-sm font-semibold text-slate-300 print:text-slate-600">Round {item.round} (2024 Actual)</div>
                                  <div className="text-xs sm:text-sm font-mono text-slate-300 print:text-slate-600">{item.openingRank.toLocaleString()}</div>
                                  <div className="text-xs sm:text-sm font-mono text-slate-300 print:text-slate-600">{item.closingRank.toLocaleString()}</div>
                                </div>
          
                                <div className="grid grid-cols-3 gap-2 sm:gap-4 p-3 sm:px-5 bg-brand-500/10 items-center print:bg-brand-50">
                                  <div className="text-xs sm:text-sm font-bold text-brand-400 flex items-center gap-1.5 print:text-brand-800">
                                    Round {item.round} (2025 Prediction) <span className="w-2 h-2 rounded-full bg-brand-500 animate-pulse print:hidden" />
                                  </div>
                                  <div className="text-sm font-mono font-bold text-brand-400 print:text-brand-800">{item.expectedOpeningRank.toLocaleString()}</div>
                                  <div className="flex items-center gap-3">
                                     <div className="text-sm font-mono font-bold text-brand-400 print:text-brand-800">{item.expectedClosingRank.toLocaleString()}</div>
                                     
                                     {(item.expectedClosingRank - Number(rank)) >= 0 ? (
                                       <div className="hidden sm:flex text-[10px] items-center gap-1 text-emerald-400 font-bold bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20 print:text-emerald-700 print:bg-emerald-50 print:border-emerald-200">
                                         Safe +{(item.expectedClosingRank - Number(rank)).toLocaleString()}
                                       </div>
                                     ) : (
                                       <div className="hidden sm:flex text-[10px] items-center gap-1 text-red-400 font-bold bg-red-500/10 px-1.5 py-0.5 rounded border border-red-500/20 print:text-red-700 print:bg-red-50 print:border-red-200">
                                         Lag {Math.abs(item.expectedClosingRank - Number(rank)).toLocaleString()}
                                       </div>
                                     )}
                                  </div>
                                </div>
                              </motion.div>
                            ))}
                          </motion.div>

                          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-8">
                            <div className="bg-[#0b0e14] p-4 rounded-xl border border-white/5 print:border-slate-200 print:bg-slate-50">
                              <div className="flex items-center gap-2 text-slate-500 text-xs sm:text-sm font-semibold mb-1 print:text-slate-600">
                                <Award className="w-4 h-4" /> Established
                              </div>
                              <div className="text-white font-bold text-lg print:text-slate-900">{group.college.established}</div>
                            </div>
                            <div className="bg-[#0b0e14] p-4 rounded-xl border border-white/5 print:border-slate-200 print:bg-slate-50">
                               <div className="flex items-center gap-2 text-slate-500 text-xs sm:text-sm font-semibold mb-1 print:text-slate-600">
                                <Banknote className="w-4 h-4" /> Avg Fee
                              </div>
                              <div className="text-white font-bold text-lg print:text-slate-900">{group.college.fees}</div>
                            </div>
                            <div className="bg-[#0b0e14] p-4 rounded-xl border border-white/5 print:border-slate-200 print:bg-slate-50">
                               <div className="flex items-center gap-2 text-slate-500 text-xs sm:text-sm font-semibold mb-1 print:text-slate-600">
                                <TrendingUp className="w-4 h-4 text-emerald-500" /> High Package
                              </div>
                              <div className="text-white font-bold text-lg print:text-slate-900">{group.college.highestPackage}</div>
                            </div>
                            <div className="bg-[#0b0e14] p-4 rounded-xl border border-white/5 print:border-slate-200 print:bg-slate-50">
                               <div className="flex items-center gap-2 text-slate-500 text-xs sm:text-sm font-semibold mb-1 print:text-slate-600">
                                <Minus className="w-4 h-4" /> Avg Package
                              </div>
                              <div className="text-white font-bold text-lg print:text-slate-900">{group.college.averagePackage}</div>
                            </div>
                          </div>

                          {(group.college.pros || group.college.cons) && (
                            <div className="mt-8 pt-6 border-t border-white/5 grid grid-cols-1 md:grid-cols-2 gap-6 print:border-slate-200 print:page-break-inside-avoid">
                              {group.college.pros && (
                                <div className="bg-emerald-500/5 rounded-xl border border-emerald-500/10 p-5 print:bg-emerald-50 print:border-emerald-200">
                                  <h4 className="text-sm font-bold text-emerald-400 mb-4 flex items-center gap-2 print:text-emerald-800">
                                    <CheckCircle2 className="w-4 h-4" /> Why you should join
                                  </h4>
                                  <ul className="space-y-3">
                                    {group.college.pros.map((pro, i) => (
                                      <li key={i} className="text-slate-300 text-sm flex items-start gap-2 print:text-slate-700">
                                        <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0 print:bg-emerald-600" /> <span className="leading-snug">{pro}</span>
                                      </li>
                                    ))}
                                  </ul>
                                </div>
                              )}
                              {group.college.cons && (
                                <div className="bg-red-500/5 rounded-xl border border-red-500/10 p-5 print:bg-red-50 print:border-red-200">
                                  <h4 className="text-sm font-bold text-red-400 mb-4 flex items-center gap-2 print:text-red-800">
                                    <XCircle className="w-4 h-4" /> Things to consider
                                  </h4>
                                  <ul className="space-y-3">
                                    {group.college.cons.map((con, i) => (
                                      <li key={i} className="text-slate-300 text-sm flex items-start gap-2 print:text-slate-700">
                                        <div className="w-1.5 h-1.5 rounded-full bg-red-500 mt-1.5 shrink-0 print:bg-red-600" /> <span className="leading-snug">{con}</span>
                                      </li>
                                    ))}
                                  </ul>
                                </div>
                              )}
                            </div>
                          )}

                          {group.college.reviews && group.college.reviews.length > 0 && (
                            <div className="mt-8 border-t border-white/5 pt-6 print:hidden">
                              <h4 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
                                <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" /> Verified Reviews
                              </h4>
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                {group.college.reviews.map((review, rIdx) => (
                                  <div key={rIdx} className="bg-[#151a22] p-4 rounded-xl border border-white/5 relative overflow-hidden group">
                                    <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none transition-opacity group-hover:opacity-10">
                                      <FileText className="w-12 h-12 text-white" />
                                    </div>
                                    <div className="flex items-center gap-1 mb-2">
                                      {Array(review.rating).fill(0).map((_, i) => (
                                        <Star key={i} className="w-3 h-3 text-yellow-500 fill-yellow-500" />
                                      ))}
                                    </div>
                                    <p className="text-slate-300 text-sm italic mb-3 relative z-10">"{review.text}"</p>
                                    <p className="text-xs font-bold text-slate-500 relative z-10">- {review.user}</p>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}

                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
