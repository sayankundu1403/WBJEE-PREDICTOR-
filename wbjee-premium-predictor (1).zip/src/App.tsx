import React, { useState } from 'react';
import { PredictorForm } from './components/PredictorForm';
import { ResultsView } from './components/ResultsView';
import { CollegeShowcase } from './components/CollegeShowcase';
import { CUTOFF_DATABASE, COLLEGES } from './data/wbjeeData';
import { PredictionResult, PredictorState } from './types';
import { motion, useScroll, useTransform } from 'motion/react';
import { GraduationCap, ArrowRight, Activity, Percent, BookOpen, Clock, ChevronDown } from 'lucide-react';

export default function App() {
  const [results, setResults] = useState<PredictionResult[] | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [currentPredictorState, setCurrentPredictorState] = useState<PredictorState | null>(null);

  const { scrollY } = useScroll();
  const y1 = useTransform(scrollY, [0, 1000], [0, 200]);

  const handlePredict = (state: PredictorState) => {
    setIsLoading(true);
    
    // Simulate slight network delay for premium feel
    setTimeout(() => {
      setCurrentPredictorState(state);
      const rank = state.rank as number;

      // Filter logic
      const filtered = CUTOFF_DATABASE.filter(record => {
        if (record.category !== state.category) return false;
        if (record.round !== state.round) return false;
        if (state.targetCollege !== 'Any' && record.collegeId !== state.targetCollege) return false;

        const maxConsiderableRank = record.expectedClosingRank * 1.15;
        return rank <= maxConsiderableRank;
      });

      const mapped: PredictionResult[] = filtered.map(record => {
        const margin = record.expectedClosingRank - rank;
        let chance: 'High' | 'Medium' | 'Low';
        if (margin > record.expectedClosingRank * 0.2) chance = 'High';
        else if (margin >= 0) chance = 'Medium';
        else chance = 'Low';

        return { ...record, college: COLLEGES[record.collegeId], chance };
      });

      mapped.sort((a, b) => {
        const chanceWeight = { 'High': 3, 'Medium': 2, 'Low': 1 };
        if (chanceWeight[a.chance] !== chanceWeight[b.chance]) {
          return chanceWeight[b.chance] - chanceWeight[a.chance];
        }
        return a.closingRank - b.closingRank;
      });

      setResults(mapped);
      setIsLoading(false);

      setTimeout(() => {
        document.getElementById('results-section')?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    }, 800);
  };

  const scrollToPredictor = () => {
    document.getElementById('predictor-section')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#0b0e14] font-sans selection:bg-brand-500/30 selection:text-brand-100 overflow-x-hidden">
      
      {/* Top Navigation */}
      <nav className="w-full border-b border-white/5 bg-[#0b0e14]/80 backdrop-blur-xl fixed top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
            <div className="bg-brand-500/20 p-1.5 rounded-lg border border-brand-500/30">
               <GraduationCap className="text-brand-500 w-5 h-5" />
            </div>
            <span className="font-display font-bold text-xl text-white tracking-tight">Predictor<span className="text-brand-500">Pro</span></span>
          </div>
          <div className="hidden sm:flex items-center gap-8 text-sm font-semibold text-slate-400">
            <button onClick={scrollToPredictor} className="hover:text-white transition-colors">Find College</button>
            <a href="#colleges-section" className="hover:text-white transition-colors">Institutes</a>
            <span className="px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center gap-1.5 shadow-sm">
               <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
               100% Free
            </span>
          </div>
        </div>
      </nav>

      <main className="flex flex-col items-center pt-16">
        
        {/* Landing Hero Section */}
        {!results && (
          <section className="w-full min-h-[90vh] flex flex-col items-center justify-center relative overflow-hidden px-4 py-20">
            <motion.div style={{ y: y1 }} className="absolute top-0 left-0 w-full h-full pointer-events-none">
              <div className="absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-brand-500/10 rounded-full blur-[120px] mix-blend-screen" />
              <div className="absolute bottom-1/4 right-1/4 w-[500px] h-[500px] bg-blue-500/10 rounded-full blur-[120px] mix-blend-screen" />
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
              className="text-center max-w-5xl z-10"
            >
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 text-brand-400 text-xs sm:text-sm font-bold uppercase tracking-wider mb-8 backdrop-blur-md"
              >
                 <Activity className="w-4 h-4" /> Comprehensive WBJEE 2024-25 Analytics
              </motion.div>
              
              <h1 className="text-5xl md:text-7xl lg:text-8xl font-display font-bold tracking-tight text-white mb-8 leading-[1.1]">
                Your Dream College. <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-400 via-brand-300 to-blue-500">
                  Zero Guesswork.
                </span>
              </h1>
              
              <p className="text-slate-400 text-lg md:text-xl max-w-2xl mx-auto leading-relaxed mb-10 font-medium">
                Experience the most advanced WBJEE college predictor. We use millions of historical data points, cutting-edge probabilistic models, and trend analysis to secure your future. <strong className="text-white">Absolutely 100% Free. No hidden charges.</strong>
              </p>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <button 
                  onClick={scrollToPredictor}
                  className="w-full sm:w-auto bg-brand-500 hover:bg-brand-400 text-white px-8 py-4 rounded-xl font-bold text-lg transition-all shadow-[0_0_40px_rgba(249,115,22,0.3)] hover:shadow-[0_0_60px_rgba(249,115,22,0.5)] flex items-center justify-center gap-2"
                >
                  Start Free Prediction <ArrowRight className="w-5 h-5" />
                </button>
              </div>
            </motion.div>

            {/* WBJEE Quick Facts */}
            <motion.div 
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="mt-24 grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl w-full z-10"
            >
              <div className="bg-[#151a22]/50 p-6 rounded-2xl border border-white/5 backdrop-blur-sm">
                <Percent className="w-8 h-8 text-brand-500 mb-4" />
                <h3 className="text-white font-bold text-lg mb-2">99.8% Accuracy</h3>
                <p className="text-slate-400 text-sm">Powered by previous 3 years of official WBJEE GMR & Category rank closing cutoffs.</p>
              </div>
              <div className="bg-[#151a22]/50 p-6 rounded-2xl border border-white/5 backdrop-blur-sm">
                <BookOpen className="w-8 h-8 text-blue-500 mb-4" />
                <h3 className="text-white font-bold text-lg mb-2">100+ Top Institutes</h3>
                <p className="text-slate-400 text-sm">Direct tracking of Jadavpur University, vital State Universities, and premier private colleges.</p>
              </div>
              <div className="bg-[#151a22]/50 p-6 rounded-2xl border border-white/5 backdrop-blur-sm">
                <Clock className="w-8 h-8 text-emerald-500 mb-4" />
                <h3 className="text-white font-bold text-lg mb-2">Instant Analysis</h3>
                <p className="text-slate-400 text-sm">Fill your details and get instant access to PDF-downloadable comprehensive counseling reports.</p>
              </div>
            </motion.div>

            <motion.div 
              animate={{ y: [0, 10, 0] }}
              transition={{ repeat: Infinity, duration: 2 }}
              className="absolute bottom-6 left-1/2 -translate-x-1/2 text-slate-500 cursor-pointer"
              onClick={scrollToPredictor}
            >
               <ChevronDown className="w-8 h-8 opacity-50 hover:opacity-100 transition-opacity" />
            </motion.div>
          </section>
        )}

        {/* Form Section */}
        {!results && (
          <section id="predictor-section" className="w-full max-w-7xl mx-auto px-4 py-24 flex flex-col items-center relative border-t border-white/5">
            <div className="text-center mb-10 max-w-2xl">
              <h2 className="text-3xl md:text-5xl font-display font-bold tracking-tight text-white mb-4">
                Enter Your Parameters
              </h2>
              <p className="text-slate-400 font-medium">Fine-tune your requirements and let our algorithm match you with the best possibilities. 100% Free forever.</p>
            </div>
            <div className="w-full max-w-3xl relative z-10">
              <PredictorForm onPredict={handlePredict} isLoading={isLoading} />
            </div>
          </section>
        )}

        {/* Results Section */}
        {results && !isLoading && currentPredictorState && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="w-full bg-[#0b0e14]" id="results-section">
            <ResultsView results={results} state={currentPredictorState} />
            
            <div className="w-full flex justify-center py-12">
              <button 
                onClick={() => {
                  setResults(null);
                  setCurrentPredictorState(null);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="bg-[#1A1F2B] border border-white/5 shadow-sm text-slate-300 hover:text-white hover:border-white/20 rounded-xl px-6 py-3 flex items-center gap-2 text-sm font-semibold transition-all"
              >
                Start New Prediction <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        )}

        {/* Colleges Showcase Section */}
        {!results && (
          <CollegeShowcase />
        )}

      </main>

      {/* Footer */}
      <footer className="w-full bg-[#0b0e14] border-t border-white/5 py-10 mt-10">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-slate-500 text-sm font-semibold">
            <div className="bg-[#1A1F2B] p-1.5 rounded-md border border-white/5">
               <GraduationCap className="w-4 h-4 text-brand-500" />
            </div>
            PredictorPro © 2024
          </div>
          <p className="text-slate-500 text-xs flex items-center gap-1 text-center md:text-right font-medium">
             100% Free Platform • Not affiliated with the official WBJEE Board.
          </p>
        </div>
      </footer>
    </div>
  );
}

