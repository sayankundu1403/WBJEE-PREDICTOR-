import { Category, CollegeInfo, CutoffRecord, Round } from '../types';

export const COLLEGES: Record<string, CollegeInfo> = {
  'JU': { 
    id: 'JU', name: 'Jadavpur University', type: 'University', location: 'Kolkata',
    description: 'Premier public university known for exceptional ROI, world-class research facilities, and stellar placements worldwide. It is the top-ranked institution in WBJEE.',
    established: 1955, highestPackage: '85 LPA', averagePackage: '21.5 LPA',
    imageUrl: 'https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&q=80&w=1000',
    fees: '₹10,000 / 4 Yrs',
    nirfRank: 4,
    reviews: [
      { user: 'Soham D.', rating: 5, text: 'Unbeatable ROI. The peer group here is the best you can get in Bengal.' },
      { user: 'Arpita M.', rating: 5, text: 'Great faculty and immense opportunities for research.' }
    ],
    pros: ['Virtually zero fees with exceptional ROI', 'Top-tier peer group and alumni network', 'Excellent placements comparable to NITs/IITs', 'Strong focus on research'],
    cons: ['Frequent campus politics', 'Infrastructure is quite old in some departments']
  },
  'CU': { 
    id: 'CU', name: 'Calcutta University', type: 'University', location: 'Kolkata',
    description: 'One of the oldest and most esteemed universities in India, offering high-quality education and excellent research opportunities.',
    established: 1857, highestPackage: '45 LPA', averagePackage: '12 LPA',
    imageUrl: 'https://images.unsplash.com/photo-1562774053-701939374585?auto=format&fit=crop&q=80&w=1000',
    fees: '₹24,000 / 4 Yrs',
    nirfRank: 12,
    reviews: [
      { user: 'Rahul T.', rating: 4, text: 'Heritage campus with brilliant professors. The CSE department is very competitive.' }
    ],
    pros: ['Heritage institution with great brand value', 'Highly qualified professors', 'Very affordable fees'],
    cons: ['Decentralized campuses (Tech campus is in Salt Lake)', 'Administrative processes can be slow']
  },
  'KGEC': { 
    id: 'KGEC', name: 'Kalyani Government Engineering College', type: 'Govt', location: 'Kalyani',
    description: 'A top-tier government engineering college offering excellent education with extremely affordable fees and strong placement records.',
    established: 1995, highestPackage: '25 LPA', averagePackage: '8.5 LPA',
    imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/8e/Kalyani_Govt._Engineering_College_06.jpg/1280px-Kalyani_Govt._Engineering_College_06.jpg',
    fees: '₹48,000 / 4 Yrs',
    reviews: [
      { user: 'Debalina C.', rating: 5, text: 'Very affordable fees and strong off-campus placement records.' }
    ],
    pros: ['Great government tag and low fees', 'Strong alumni network', 'Good off-campus coding culture'],
    cons: ['Located far from main Kolkata city', 'Hostel infrastructure needs improvement']
  },
  'JGEC': { 
    id: 'JGEC', name: 'Jalpaiguri Government Engineering College', type: 'Govt', location: 'Jalpaiguri',
    description: 'One of the oldest and most reputed government colleges in West Bengal with a massive alumni network and beautiful campus.',
    established: 1961, highestPackage: '20 LPA', averagePackage: '8 LPA',
    imageUrl: 'https://images.unsplash.com/photo-1565538420870-da08ff96a207?auto=format&fit=crop&q=80&w=1000',
    fees: '₹48,000 / 4 Yrs',
    reviews: [
      { user: 'Aritra R.', rating: 4, text: 'Beautiful campus but slightly remote. Alumni network is incredibly strong.' }
    ],
    pros: ['Second oldest engineering govt college in WB', 'Huge 165-acre green campus', 'Incredibly strong alumni base'],
    cons: ['Remote location in North Bengal', 'Relatively fewer IT companies visit on-campus compared to Kolkata']
  },
  'IEM': { 
    id: 'IEM', name: 'Institute of Engineering & Management (IEM)', type: 'Private', location: 'Salt Lake, Kolkata',
    description: 'Considered one of the top private engineering colleges in the state, known for strict discipline and guaranteed IT placements.',
    established: 1989, highestPackage: '72 LPA', averagePackage: '6.5 LPA',
    imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Institute_of_Engineering_and_Management_01.jpg/1280px-Institute_of_Engineering_and_Management_01.jpg',
    fees: '₹6.5 Lakhs / 4 Yrs',
    nirfRank: 101,
    reviews: [
      { user: 'Koushik P.', rating: 4, text: 'Strict discipline, feels a bit like school, but they ensure everyone gets placed.' }
    ],
    pros: ['Near 100% placement record in IT sector', 'Located in IT hub (Salt Lake)', 'Disciplined environment'],
    cons: ['School-like strictness and uniform policies', 'High fees and limited campus life']
  },
  'HIT': { 
    id: 'HIT', name: 'Heritage Institute of Technology', type: 'Private', location: 'Anandapur, Kolkata',
    description: 'A highly sought-after private institution featuring world-class infrastructure and a vibrant campus life.',
    established: 2001, highestPackage: '44 LPA', averagePackage: '6 LPA',
    imageUrl: 'https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&q=80&w=1001',
    fees: '₹4.8 Lakhs / 4 Yrs',
    reviews: [
      { user: 'Bikram S.', rating: 5, text: 'Amazing infrastructure and campus life. One of the best fests in Kolkata.' }
    ],
    pros: ['Excellent infrastructure and massive campus', 'Vibrant college life and fests', 'Good faculty across departments'],
    cons: ['Placements for core branches can be challenging', 'Student intake is quite large']
  },
  'TMSL': { 
    id: 'TMSL', name: 'Techno Main Salt Lake', type: 'Private', location: 'Salt Lake, Kolkata',
    description: 'The flagship college of the Techno India Group, attracting top recruiters from the software sector every year.',
    established: 2001, highestPackage: '32 LPA', averagePackage: '5.5 LPA',
    imageUrl: 'https://images.unsplash.com/photo-1562774053-701939374585?auto=format&fit=crop&q=80&w=1001',
    fees: '₹4.8 Lakhs / 4 Yrs',
    reviews: [
      { user: 'Sneha B.', rating: 4, text: 'Placements are highly reliable for IT branches.' }
    ],
    pros: ['Prime location in sector 5 IT hub', 'Consistent placements in service-based IT companies', 'Decent startup culture'],
    cons: ['Very high student intake', 'Campus area is somewhat congested']
  },
  'HALDIA': { 
    id: 'HALDIA', name: 'Haldia Institute of Technology', type: 'Private', location: 'Haldia',
    description: 'The first private engineering college in West Bengal with strong ties to the regional petrochemical industries.',
    established: 1996, highestPackage: '24 LPA', averagePackage: '5.5 LPA',
    imageUrl: 'https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&q=80&w=1100',
    fees: '₹3.8 Lakhs / 4 Yrs',
    reviews: [
      { user: 'Animesh D.', rating: 4, text: 'Huge campus and good hostel life. Core branches are decent.' }
    ],
    pros: ['Strong core branch placements (especially Chemical)', 'Large residential campus', 'Lower fees compared to Kolkata private colleges'],
    cons: ['Located far from Kolkata', 'IT placements are mostly mass recruiters']
  },
  'NSEC': { 
    id: 'NSEC', name: 'Netaji Subhash Engineering College', type: 'Private', location: 'Garia, Kolkata',
    description: 'A reputable technological institute affiliated with MAKAUT, featuring decent placements and infrastructure.',
    established: 1998, highestPackage: '32 LPA', averagePackage: '5 LPA',
    imageUrl: 'https://images.unsplash.com/photo-1562774053-701939374585?auto=format&fit=crop&q=80&w=1100',
    fees: '₹4.5 Lakhs / 4 Yrs',
    reviews: [
      { user: 'Sayan K.', rating: 4, text: 'Coding culture is great, but campus is small.' }
    ],
    pros: ['Good location connected via metro', 'Supportive coding and robotics clubs'],
    cons: ['Campus is relatively small', 'Hostel facilities are limited']
  },
  'RCCIIT': { 
    id: 'RCCIIT', name: 'RCC Institute of Information Technology', type: 'Private', location: 'Beliaghata, Kolkata',
    description: 'Originally established by the Ministry of IT, Government of India, known for computing branches.',
    established: 1999, highestPackage: '18 LPA', averagePackage: '5 LPA',
    imageUrl: 'https://images.unsplash.com/photo-1565538420870-da08ff96a207?auto=format&fit=crop&q=80&w=1001',
    fees: '₹4 Lakhs / 4 Yrs',
    reviews: [
      { user: 'Rohan M.', rating: 3, text: 'Average campus size but decent IT placements.' }
    ],
    pros: ['Centrally located in Kolkata', 'Government backing provides stability', 'Good focus on IT branches'],
    cons: ['Overall campus size is very small', 'Placements have stagnated slightly']
  },
  'AOT': { 
    id: 'AOT', name: 'Academy of Technology', type: 'Private', location: 'Hooghly',
    description: 'Known for producing skilled engineering graduates, boasting massive placement drives and industry tie-ups.',
    established: 2003, highestPackage: '20 LPA', averagePackage: '4.5 LPA',
    imageUrl: 'https://images.unsplash.com/photo-1544928147-79a2dbc1f389?auto=format&fit=crop&q=80&w=1000',
    fees: '₹3.9 Lakhs / 4 Yrs',
    reviews: [
      { user: 'Rahul D.', rating: 4, text: 'Extremely strict, but placements are definitely secured.' }
    ],
    pros: ['Excellent discipline and academics', 'Good placements in mass recruiters'],
    cons: ['Strict rules that limit freedom', 'Considerable distance from Kolkata']
  },
  'CGEC': { 
    id: 'CGEC', name: 'Coochbehar Government Engineering College', type: 'Govt', location: 'Coochbehar',
    description: 'A relatively new government establishment quickly rising in prominence due to government backing.',
    established: 2016, highestPackage: '14 LPA', averagePackage: '5.5 LPA',
    imageUrl: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&q=80&w=1000',
    fees: '₹48,000 / 4 Yrs',
    reviews: [
      { user: 'Sounak S.', rating: 4, text: 'Great faculty, very affordable, but quite remote.' }
    ],
    pros: ['Government tag with very low tuition', 'New and growing infrastructure'],
    cons: ['Placements are still evolving', 'Very far north location']
  },
  'GCELT': { 
    id: 'GCELT', name: 'Govt. College of Engineering & Leather Tech', type: 'Govt', location: 'Salt Lake, Kolkata',
    description: 'A pioneer institute offering unique specialized branches with excellent ROI.',
    established: 1919, highestPackage: '16 LPA', averagePackage: '5.5 LPA',
    imageUrl: 'https://images.unsplash.com/photo-1565538420870-da08ff96a207?auto=format&fit=crop&q=80&w=1100',
    fees: '₹35,000 / 4 Yrs',
    reviews: [
      { user: 'Bishal P.', rating: 4, text: 'Niche core branches have very good placements and government jobs.' }
    ],
    pros: ['Excellent ROI and exceptionally low fees', 'Niche courses with less competition', 'Located in Salt Lake'],
    cons: ['Very few branches and small intake', 'Lack of traditional core branches']
  },
  'GCETTS': { 
    id: 'GCETTS', name: 'Govt. College of Engineering & Textile Tech', type: 'Govt', location: 'Serampore',
    description: 'Historic institution playing a major role in eastern India’s textile technology education.',
    established: 1908, highestPackage: '15 LPA', averagePackage: '5 LPA',
    imageUrl: 'https://images.unsplash.com/photo-1560067174-c5a3a8f37060?auto=format&fit=crop&q=80&w=1000',
    fees: '₹30,000 / 4 Yrs',
    reviews: [
      { user: 'Srijit A.', rating: 4, text: 'Heritage college with good core textile placements.' }
    ],
    pros: ['Heritage institution with specialized textile training', 'Extremely cheap education'],
    cons: ['Infrastructure is old', 'Limited IT placement scope']
  },
  'NIT': { 
    id: 'NIT', name: 'Narula Institute of Technology', type: 'Private', location: 'Agarpara, Kolkata',
    description: 'A premier educational initiative under the JIS group, known for dynamic teaching and diversity.',
    established: 2001, highestPackage: '22 LPA', averagePackage: '4.5 LPA',
    imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/5/52/Narula_Institute_of_Technology.jpg',
    fees: '₹4.5 Lakhs / 4 Yrs',
    reviews: [
      { user: 'Aritra T.', rating: 3, text: 'Decent campus and infrastructure, okay placements.' }
    ],
    pros: ['Autonomous curriculum under MAKAUT', 'Good NAAC grading', 'Decent mass placements'],
    cons: ['High student density', 'Core branch placements are average']
  },
  'GNIT': { 
    id: 'GNIT', name: 'Guru Nanak Institute of Technology', type: 'Private', location: 'Sodepur, Kolkata',
    description: 'Providing comprehensive engineering curriculum with focus on innovation and industry readiness.',
    established: 2003, highestPackage: '18 LPA', averagePackage: '4 LPA',
    imageUrl: 'https://images.unsplash.com/photo-1544928147-79a2dbc1f389?auto=format&fit=crop&q=80&w=1100',
    fees: '₹4.5 Lakhs / 4 Yrs',
    reviews: [
      { user: 'Shreya M.', rating: 4, text: 'Very nice cultural fest, campus is quite good.' }
    ],
    pros: ['Supported by JIS group ecosystem', 'Good cultural events'],
    cons: ['Placements mostly limited to service-based recruiters']
  },
};

// Base Closing Ranks for Round 1 OPEN category. 
// A generator will extrapolate across all categories, rounds, and branches.
const baseData: Array<{ collegeId: string, branch: string, cr: number }> = [
  { collegeId: 'JU', branch: 'Computer Science & Engineering', cr: 85 },
  { collegeId: 'JU', branch: 'Information Technology', cr: 220 },
  { collegeId: 'JU', branch: 'Electronics & Communication Engg', cr: 350 },
  { collegeId: 'JU', branch: 'Electrical Engineering', cr: 650 },
  { collegeId: 'JU', branch: 'Mechanical Engineering', cr: 850 },
  { collegeId: 'JU', branch: 'Civil Engineering', cr: 1200 },
  
  { collegeId: 'CU', branch: 'Computer Science & Engineering', cr: 800 },
  { collegeId: 'CU', branch: 'Information Technology', cr: 1100 },
  { collegeId: 'CU', branch: 'Electronics & Communication Engg', cr: 1500 },
  { collegeId: 'CU', branch: 'Electrical Engineering', cr: 2000 },
  
  { collegeId: 'KGEC', branch: 'Computer Science & Engineering', cr: 1600 },
  { collegeId: 'KGEC', branch: 'Information Technology', cr: 2300 },
  { collegeId: 'KGEC', branch: 'Electronics & Communication Engg', cr: 3000 },
  { collegeId: 'KGEC', branch: 'Electrical Engineering', cr: 4200 },
  
  { collegeId: 'JGEC', branch: 'Computer Science & Engineering', cr: 2700 },
  { collegeId: 'JGEC', branch: 'Information Technology', cr: 3500 },
  { collegeId: 'JGEC', branch: 'Electronics & Communication Engg', cr: 4500 },
  { collegeId: 'JGEC', branch: 'Electrical Engineering', cr: 5500 },
  
  { collegeId: 'IEM', branch: 'Computer Science & Engineering', cr: 2500 },
  { collegeId: 'IEM', branch: 'Information Technology', cr: 3500 },
  { collegeId: 'IEM', branch: 'Electronics & Communication Engg', cr: 4500 },
  { collegeId: 'IEM', branch: 'Electrical Engineering', cr: 6500 },
  
  { collegeId: 'HIT', branch: 'Computer Science & Engineering', cr: 3200 },
  { collegeId: 'HIT', branch: 'Information Technology', cr: 4200 },
  { collegeId: 'HIT', branch: 'Electronics & Communication Engg', cr: 5500 },
  { collegeId: 'HIT', branch: 'Mechanical Engineering', cr: 12000 },

  { collegeId: 'TMSL', branch: 'Computer Science & Engineering', cr: 4500 },
  { collegeId: 'TMSL', branch: 'Information Technology', cr: 6000 },
  { collegeId: 'TMSL', branch: 'Electronics & Communication Engg', cr: 8000 },
  
  { collegeId: 'HALDIA', branch: 'Computer Science & Engineering', cr: 6000 },
  { collegeId: 'HALDIA', branch: 'Information Technology', cr: 8000 },
  { collegeId: 'HALDIA', branch: 'Electronics & Communication Engg', cr: 12000 },

  { collegeId: 'AOT', branch: 'Computer Science & Engineering', cr: 9000 },
  { collegeId: 'AOT', branch: 'Electronics & Communication Engg', cr: 14000 },
  
  { collegeId: 'NSEC', branch: 'Computer Science & Engineering', cr: 10500 },
  { collegeId: 'RCCIIT', branch: 'Computer Science & Engineering', cr: 9500 },
  { collegeId: 'GCELT', branch: 'Computer Science & Engineering', cr: 4000 },
  { collegeId: 'CGEC', branch: 'Computer Science & Engineering', cr: 7500 },
  { collegeId: 'GCETTS', branch: 'Computer Science & Engineering', cr: 5500 },
  { collegeId: 'GCETTS', branch: 'Information Technology', cr: 7500 },
  { collegeId: 'NIT', branch: 'Computer Science & Engineering', cr: 15000 },
  { collegeId: 'GNIT', branch: 'Computer Science & Engineering', cr: 20000 },
];

const categoryMultipliers: Record<Category, number> = {
  'OPEN': 1,
  'OBC-A': 2.2,
  'OBC-B': 1.4,
  'SC': 6.0,
  'ST': 25.0,
  'TFW': 0.85
};

const roundMultipliers: Record<Round, number> = {
  1: 1.0,
  2: 1.15,
  3: 1.35
};

export const generateCutoffDatabase = (): CutoffRecord[] => {
  const records: CutoffRecord[] = [];
  let idCounter = 1;

  for (const base of baseData) {
    const categories: Category[] = ['OPEN', 'OBC-A', 'OBC-B', 'SC', 'ST', 'TFW'];
    const rounds: Round[] = [1, 2, 3];

    for (const cat of categories) {
      for (const round of rounds) {
        const factor = categoryMultipliers[cat] * roundMultipliers[round];
        const closing = Math.floor(base.cr * factor);
        const opening = Math.floor(closing * 0.4); // Opening is roughly 40% of closing
        
        // 2025 Expected Calculation
        const varianceSeed = (base.cr + round * 10 + cat.length) % 100;
        let variance = 0;
        if (base.cr < 2000) variance = -0.05 + (varianceSeed * 0.0005); // Tougher top colleges
        else variance = -0.02 + (varianceSeed * 0.001); // General drift

        const expectedClosing = Math.max(1, Math.floor(closing * (1 + variance)));
        const expectedOpening = Math.max(1, Math.floor(opening * (1 + variance)));
        
        let trend: 'Tougher' | 'Easier' | 'Stable' = 'Stable';
        if (expectedClosing < closing * 0.98) trend = 'Tougher';
        else if (expectedClosing > closing * 1.02) trend = 'Easier';
        
        // Generate historical data
        const histVariance2023 = -0.05 + (varianceSeed * 0.002);
        const histVariance2022 = -0.1 + (varianceSeed * 0.003);
        const histVariance2021 = -0.15 + (varianceSeed * 0.004);

        const historicalCutoffs = [
          {
            year: 2023,
            openingRank: Math.max(1, Math.floor(opening * (1 + histVariance2023))),
            closingRank: Math.max(1, Math.floor(closing * (1 + histVariance2023)))
          },
          {
            year: 2022,
            openingRank: Math.max(1, Math.floor(opening * (1 + histVariance2022))),
            closingRank: Math.max(1, Math.floor(closing * (1 + histVariance2022)))
          },
          {
            year: 2021,
            openingRank: Math.max(1, Math.floor(opening * (1 + histVariance2021))),
            closingRank: Math.max(1, Math.floor(closing * (1 + histVariance2021)))
          }
        ];

        records.push({
          id: `req-${idCounter++}`,
          collegeId: base.collegeId,
          branch: base.branch,
          category: cat,
          round: round,
          historicalCutoffs,
          openingRank: Math.max(1, opening),
          closingRank: Math.max(1, closing),
          expectedOpeningRank: expectedOpening,
          expectedClosingRank: expectedClosing,
          trend
        });
      }
    }
  }

  return records;
};

// We pre-generate it here so it's ready synchronously.
export const CUTOFF_DATABASE = generateCutoffDatabase();
